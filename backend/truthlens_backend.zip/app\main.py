import os
import time
import random
from typing import List
from fastapi import FastAPI, UploadFile, File, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from . import models, schemas, database

app = FastAPI(title="TruthLens API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

models.Base.metadata.create_all(bind=database.engine)

UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

@app.get("/")
def read_root():
    return {"status": "running"}

@app.post("/api/detect", response_model=schemas.DetectionResult)
async def detect_video(file: UploadFile = File(...), db: Session = Depends(database.get_db)):
    start_time = time.time()
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    try:
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File save error: {str(e)}")

    video_score = round(random.uniform(0.6, 0.95), 2)
    audio_score = round(random.uniform(0.4, 0.8), 2)
    lip_score = round(random.uniform(0.5, 0.9), 2)
    confidence = round((0.6 * video_score) + (0.2 * audio_score) + (0.2 * lip_score), 2)

    if confidence < 0.4:
        verdict = "Authentic"
    elif confidence <= 0.7:
        verdict = "Suspicious"
    else:
        verdict = "Likely Fake"

    flags = []
    if lip_score < 0.7: flags.append("Lip-sync mismatch")
    if audio_score < 0.6: flags.append("Audio anomaly")
    if video_score > 0.85: flags.append("High artifact density")

    reasons = []
    if "Lip-sync mismatch" in flags: reasons.append("inconsistent lip movement")
    if "Audio anomaly" in flags: reasons.append("irregular audio patterns")
    if "High artifact density" in flags and verdict == "Likely Fake": reasons.append("visual synthesis artifacts")
    
    reason = f"{' and '.join(reasons).capitalize()} detected during scan." if reasons else "No significant anomalies detected."
    processing_time_str = f"{round(time.time() - start_time, 2)}s"

    db_detection = models.Detection(filename=file.filename, verdict=verdict, confidence=confidence)
    db.add(db_detection)
    db.commit()
    db.refresh(db_detection)

    return {
        "verdict": verdict,
        "confidence": confidence,
        "breakdown": {"video": video_score, "audio": audio_score, "lip_sync": lip_score},
        "flags": flags,
        "reason": reason,
        "processing_time": processing_time_str
    }

@app.post("/api/batch", response_model=List[schemas.BatchResult])
async def batch_detect(files: List[UploadFile] = File(...), db: Session = Depends(database.get_db)):
    results = []
    for file in files[:5]:
        conf = round(random.uniform(0.3, 0.9), 2)
        verd = "Authentic" if conf < 0.4 else "Suspicious" if conf <= 0.7 else "Likely Fake"
        results.append({"filename": file.filename, "verdict": verd, "confidence": conf})
        db_det = models.Detection(filename=file.filename, verdict=verd, confidence=conf)
        db.add(db_det)
    db.commit()
    return results

@app.get("/api/analytics")
def get_analytics():
    return {"daily": [10, 20, 15, 30, 25], "types": {"mp4": 10, "avi": 5}}

@app.get("/api/history", response_model=List[schemas.HistoryItem])
def get_history(db: Session = Depends(database.get_db)):
    return db.query(models.Detection).order_by(models.Detection.created_at.desc()).limit(10).all()
